def read_file_line_by_line(filename):
    try:
        with open(filename, 'r') as file:
            print(f"Contents of '{filename}':\n")
            for line in file:
                print(line.strip())  # strip() removes leading/trailing whitespace
    except FileNotFoundError:
        print(f"Error: The file '{filename}' does not exist.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Specify the file name
file_name = "sample.txt"

# Call the function
read_file_line_by_line(file_name)