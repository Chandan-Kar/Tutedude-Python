def write_to_file(filename):
    data = input("Enter text to write to the file: ")
    with open(filename, 'w') as file:
        file.write(data + '\n')
    print("Data written successfully.\n")

def append_to_file(filename):
    more_data = input("Enter text to append to the file: ")
    with open(filename, 'a') as file:
        file.write(more_data + '\n')
    print("Data appended successfully.\n")

def read_and_display_file(filename):
    print(f"Final contents of '{filename}':\n")
    with open(filename, 'r') as file:
        for line in file:
            print(line.strip())

# File name
file_name = "output.txt"

# Perform operations
write_to_file(file_name)
append_to_file(file_name)
read_and_display_file(file_name)