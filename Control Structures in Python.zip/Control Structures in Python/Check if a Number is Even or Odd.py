num = int(input("Enter an integer: "))

# Step 2: Check whether the number is even or odd using if-else
if num % 2 == 0:
    # Step 3: Display result
    print(f"The number {num} is Even.")
else:
    print(f"The number {num} is Odd.")

