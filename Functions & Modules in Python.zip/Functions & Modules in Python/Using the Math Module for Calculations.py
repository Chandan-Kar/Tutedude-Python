import math

# Ask the user for a number
number = float(input("Enter a number: "))

# Check if the number is valid for sqrt and log
if number <= 0:
    print("Square root and logarithm require a positive number.")
else:
    # Calculate square root
    sqrt_result = math.sqrt(number)

    # Calculate natural logarithm
    log_result = math.log(number)

    # Calculate sine (number is assumed to be in radians)
    sine_result = math.sin(number)

    # Display the results
    print(f"\nResults for the number {number}:")
    print(f"Square root: {sqrt_result}")
    print(f"Natural logarithm (log base e): {log_result}")
    print(f"Sine (in radians): {sine_result}")