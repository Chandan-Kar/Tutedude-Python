# Function to calculate factorial using recursion
def factorial(n):
    if n < 0:
        return "Factorial is not defined for negative numbers."
    elif n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n - 1)

# Call the function with a sample number
sample_number = 5
result = factorial(sample_number)

# Print the output
print(f"The factorial of {sample_number} is {result}")